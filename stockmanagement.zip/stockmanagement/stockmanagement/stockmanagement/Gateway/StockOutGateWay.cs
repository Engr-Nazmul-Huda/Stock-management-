﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Manager;
using stockmanagement.Models;
using System.Data.SqlClient;


namespace stockmanagement.Gateway
{
    public class StockOutGateWay
    {
        SqlCommand sqlCommand;
        SqlDataReader sqlReader;
        ConnectionClass oConnectionClass = new ConnectionClass();
        public void UpdateItem(Item item)
        {


            string query = "UPDATE Items SET quantity = " + item.quantity + " WHERE itemID = " + item.ItemID;
            try
            {
                sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception exception)
            {

            }
            finally
            {
                oConnectionClass.GetClose();
            }

        }
        public int GetStockOut(StockOut stock)
        {
            int rowCount = 0;

            string query = "INSERT INTO StockOut VALUES (" + stock.ItemID + ","
                + stock.StockOutQuantity + ",'" + stock.StockOutDate + "'"+stock.StockOutStateID+")";
            try
            {
                sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
                rowCount = sqlCommand.ExecuteNonQuery();
            }
            catch (Exception exception)
            {

            }
            finally
            {
                oConnectionClass.GetClose();
            }
            return rowCount;
        }

        public List<Company> GetAllCompanys()
        {
            string query = "SELECT * FROM Company";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Company> company = new List<Company>();
            while (sqlReader.Read())
            {
                Company aCompany = new Company();
                aCompany.CompanyID = (int)sqlReader["companyID"];
                aCompany.CompanyName = sqlReader["companyName"].ToString();
                company.Add(aCompany);

            }
            sqlReader.Close();
            return company;
        }
        public List<Item> GetAllItems(Item aitem)
        {
            string query = "SELECT * FROM Items WHERE companyID =  " + aitem.companyID;
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Item> item = new List<Item>();
            while (sqlReader.Read())
            {
                Item items = new Item();
                items.ItemID = (int)sqlReader["itemID"];
                items.ItemName = sqlReader["itemName"].ToString();
                items.CategoryID = (int)sqlReader["caterogyID"];
                items.companyID = (int)sqlReader["companyID"];
                items.recordLevel = (int)sqlReader["reorderLevel"];
                items.quantity = (int)sqlReader["quantity"];
                item.Add(items);

            }
            sqlReader.Close();
            return item;
        }
        public List<Item> GetOneItem(Item aitem)
        {
            string query = "SELECT * FROM Items WHERE itemID =  " + aitem.ItemID;
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Item> item = new List<Item>();
            while (sqlReader.Read())
            {
                Item items = new Item();
                items.ItemID = (int)sqlReader["itemID"];
                items.ItemName = sqlReader["itemName"].ToString();
                items.CategoryID = (int)sqlReader["caterogyID"];
                items.companyID = (int)sqlReader["companyID"];
                items.recordLevel = (int)sqlReader["reorderLevel"];
                items.quantity = (int)sqlReader["quantity"];
                item.Add(items);

            }
            sqlReader.Close();
            return item;
        }
        public DemoStockOutItem GetGridItem(Item items,int j)
        {
            string query = "SELECT i.itemName,co.companyName,i.quantity FROM Items as i INNER JOIN Company as co " +
               "ON i.companyID = co.companyID "+
                "WHERE i.companyID = " + items.companyID + " AND i.itemID = " + items.ItemID;

            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            DemoStockOutItem item = new DemoStockOutItem();
            while (sqlReader.Read())
            {

                item.SL = ++j;
                item.ItemName = sqlReader["itemName"].ToString();
                item.Company = sqlReader["companyName"].ToString();
                item.Quantity = (int)sqlReader["quantity"];
            }
            sqlReader.Close();
            return item;
        }
    }
}