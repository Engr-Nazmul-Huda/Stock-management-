﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using stockmanagement.Models;
using stockmanagement.Manager;
using stockmanagement.Gateway;

namespace stockmanagement.Gateway
{
    public class StockInGateWay
    {
        SqlCommand sqlCommand;
        SqlDataReader sqlReader;
        ConnectionClass oConnectionClass = new ConnectionClass();

        public void UpdateItem(Item item)
        {
            string query = "UPDATE Items SET quantity = "+item.quantity+ " WHERE itemID = "+item.ItemID;
            try
            {
                sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
                sqlCommand.ExecuteNonQuery();
            }
            catch (Exception exception)
            {

            }
            finally
            {
                oConnectionClass.GetClose();
            }
           
        }
        public int GetStockIn(StockIn stock)
        {
            int rowCount = 0;

            string query = "INSERT INTO StockIn VALUES (" + stock.itemID+ ","
                +stock.stockInQuantity+",'"+stock.stockInDate+"')";
            try
            {
                sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
                rowCount = sqlCommand.ExecuteNonQuery();
            }
            catch (Exception exception)
            {

            }
            finally
            {
                oConnectionClass.GetClose();
            }
            return rowCount;
        }

        public List<Company> GetAllCompanys()
        {
            string query = "SELECT * FROM Company";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Company> company = new List<Company>();
            while (sqlReader.Read())
            {
                Company aCompany = new Company();
                aCompany.CompanyID = (int)sqlReader["companyID"];
                aCompany.CompanyName = sqlReader["companyName"].ToString();
                company.Add(aCompany);

            }
            sqlReader.Close();
            return company;
        }
        public List<Item> GetAllItems(Item aitem)
        {
            string query = "SELECT * FROM Items WHERE companyID =  "+aitem.companyID;
            //string query = "SELECT * FROM Items";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Item> item = new List<Item>();
            while (sqlReader.Read())
            {
                Item items = new Item();
                items.ItemID = (int)sqlReader["itemID"];
                items.ItemName = sqlReader["itemName"].ToString();
                items.CategoryID = (int)sqlReader["caterogyID"];
                items.companyID = (int)sqlReader["companyID"];
                items.recordLevel = (int)sqlReader["reorderLevel"];
                items.quantity = (int)sqlReader["quantity"];
                item.Add(items);

            }
            sqlReader.Close();
            return item;
        }
        public List<Item> GetOneItem(Item aitem)
        {
            string query = "SELECT * FROM Items WHERE itemID =  " + aitem.ItemID;
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Item> item = new List<Item>();
            while (sqlReader.Read())
            {
                Item items = new Item();
                items.ItemID = (int)sqlReader["itemID"];
                items.ItemName = sqlReader["itemName"].ToString();
                items.CategoryID = (int)sqlReader["caterogyID"];
                items.companyID = (int)sqlReader["companyID"];
                items.recordLevel = (int)sqlReader["reorderLevel"];
                items.quantity = (int)sqlReader["quantity"];
                item.Add(items);

            }
            sqlReader.Close();
            return item;
        }
    }
}