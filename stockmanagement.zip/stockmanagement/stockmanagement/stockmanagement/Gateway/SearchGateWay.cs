﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using stockmanagement.Gateway;
using stockmanagement.Models;
using stockmanagement.Manager;
namespace stockmanagement.Gateway
{
    public class SearchGateWay
    {
        private SqlCommand cmd;
        private SqlDataReader reader;
        ConnectionClass oConnectionClass = new ConnectionClass();


        public List<DemoItem> GetCategoryAndCompany(Search aSearch)
        {
            string query = "SELECT i.itemName,co.companyName,ca.categoryName,i.quantity,i.reorderLevel FROM Items as i INNER JOIN Company as co " +
               "ON i.companyID = co.companyID INNER JOIN Category as ca ON "+
               "i.caterogyID = ca.categoryID WHERE i.caterogyID = " + aSearch.CategoryID+ " AND i.companyID = "+aSearch.CompanyID;
            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            List<DemoItem> itemList = new List<DemoItem>();
            int i = 1;
            while (reader.Read())
            {

                DemoItem item = new DemoItem();
                item.SL = i++;
                item.Company = reader["companyName"].ToString();
                item.Category = reader["categoryName"].ToString();
                item.Available_Quantity = (int)reader["quantity"];
                item.Reorder_Level = (int) reader["reorderLevel"];
                itemList.Add(item);
            }
            reader.Close();
            return itemList;

        }
        public List<DemoItem> GetCompany(Search aSearch)
        {

            string query = "SELECT i.itemName,co.companyName,ca.categoryName,i.quantity,i.reorderLevel FROM Items as i INNER JOIN Company as co " +
               "ON i.companyID = co.companyID INNER JOIN Category as ca ON " +
               "i.caterogyID = ca.categoryID WHERE i.companyID = " + aSearch.CompanyID;

            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            List<DemoItem> itemList = new List<DemoItem>();
            int i = 1;
            while (reader.Read())
            {
                DemoItem item = new DemoItem();
                item.SL = i++;
                item.Company = reader["companyName"].ToString();
                item.Category = reader["categoryName"].ToString();
                item.Available_Quantity = (int)reader["quantity"];
                item.Reorder_Level = (int)reader["reorderLevel"];
                itemList.Add(item);
            }
            reader.Close();
            return itemList;
        }
        public List<DemoItem> GetCategory(Search aSearch)
        {

            string query = "SELECT i.itemName,co.companyName,ca.categoryName,i.quantity,i.reorderLevel FROM Items as i INNER JOIN Company as co " +
               "ON i.companyID = co.companyID INNER JOIN Category as ca ON " +
               "i.caterogyID = ca.categoryID WHERE i.caterogyID = " + aSearch.CategoryID;
            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            List<DemoItem> itemList = new List<DemoItem>();
            int i = 1;
            while (reader.Read())
            {

                DemoItem item = new DemoItem();
                item.SL = i++;
                item.Company = reader["companyName"].ToString();
                item.Category = reader["categoryName"].ToString();
                item.Available_Quantity = (int)reader["quantity"];
                item.Reorder_Level = (int)reader["reorderLevel"];
                itemList.Add(item);
            }
            reader.Close();
            return itemList;
        }
        public List<Company> GetAllCompany()
        {

            string query = "SELECT * FROM Company";
            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            List<Company> companyList = new List<Company>();
            int i = 1;
            while (reader.Read())
            {
                Company company = new Company();
                company.CompanyID = (int)reader["companyID"];
                company.CompanyName = reader["companyName"].ToString();

                companyList.Add(company);
            }
            reader.Close();
            return companyList;
        }
        public List<Category> GetAllCategory()
        {

            string query = "SELECT * FROM Category";
            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            List<Category> categoryList = new List<Category>();
            int i = 1;
            while (reader.Read())
            {
                Category category = new Category();
                category.CategoryID = (int) reader["categoryID"];
                category.CategoryName = reader["categoryName"].ToString();

                categoryList.Add(category);
            }
            reader.Close();
            return categoryList;
        }
    }
}