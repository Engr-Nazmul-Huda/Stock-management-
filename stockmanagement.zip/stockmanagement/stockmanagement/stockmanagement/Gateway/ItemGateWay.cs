﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Models;
using stockmanagement.Manager;
using System.Data.SqlClient;

namespace stockmanagement.Gateway
{
    public class ItemGateWay
    {
        SqlCommand sqlCommand;
        SqlDataReader sqlReader;
        ConnectionClass oConnectionClass = new ConnectionClass();

        public int SaveNewItem(Item item)
        {
            int rowCount = 0;
            string query = "INSERT INTO Items Values('"+item.ItemName+"',"+item.CategoryID+","+item.companyID+","
                +item.recordLevel+","+item.quantity+")";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            rowCount = sqlCommand.ExecuteNonQuery();
            oConnectionClass.GetClose();
            return rowCount;
           

        }
        public bool IsExistItem(Item item)
        {
            
            string query = "Select * FROM Items WHERE itemName = '"+item.ItemName+ "' AND caterogyID =" + item.CategoryID
               + "AND companyID = "+item.companyID + "";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            while(sqlReader.Read())
            {
                sqlReader.Close();
                oConnectionClass.GetClose();
                return true;
            }
            sqlReader.Close();
            return false;
        }
        public List<Category> GetAllCategory()
        {
            string query = "SELECT * FROM Category";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Category> category = new List<Category>();
            while(sqlReader.Read())
            {
                Category aCategory = new Category();
                aCategory.CategoryID = (int) sqlReader["categoryID"];
                aCategory.CategoryName = sqlReader["categoryName"].ToString();
                category.Add(aCategory);

            }
            sqlReader.Close();
            return  category;
        }
        public List<Company> GetAllCompany()
        {
            string query = "SELECT * FROM Company";
            sqlCommand = new SqlCommand(query, oConnectionClass.GetConnection());
            sqlReader = sqlCommand.ExecuteReader();
            List<Company> company = new List<Company>();
            while (sqlReader.Read())
            {
                Company acompany = new Company();
                acompany.CompanyID = (int)sqlReader["companyID"];
                acompany.CompanyName = sqlReader["companyName"].ToString();
                company.Add(acompany);

            }
            sqlReader.Close();
            return company;
        }
    }

}