﻿using stockmanagement.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace stockmanagement.Gateway
{
    public class CategoryGateway
    {
        private SqlCommand cmd;
        private SqlDataReader reader;
        ConnectionClass oConnectionClass = new ConnectionClass();

        public int SaveNewCategory (Category category)
        {
            int rowCount = 0;

            string query = "INSERT INTO Category VALUES ('"+category.CategoryName+"')";
            try
            {
                cmd = new SqlCommand(query, oConnectionClass.GetConnection());
                rowCount = cmd.ExecuteNonQuery();
            }
            catch(Exception exception)
            {

            }
            finally
            {
                oConnectionClass.GetClose();
            }
            return rowCount;
        }

        public bool IsExistCategoryName(string categoryName)
        {
            string query = "SELECT * FROM Category WHERE categoryName = '"+ categoryName + "'; ";
            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                oConnectionClass.GetConnection();
                return true;
            }
            return false;
        }

        public List<DemoCategory> GetAllCategory()
        {
            string query = "SELECT * FROM Category";
            cmd = new SqlCommand(query, oConnectionClass.GetConnection());
            reader = cmd.ExecuteReader();
            List<DemoCategory> categoryList = new List<DemoCategory>();
            int i = 1;
            while (reader.Read())
            {
                DemoCategory category = new DemoCategory();
                category.SL = i++;
                category.Name = reader["categoryName"].ToString();

                categoryList.Add(category);
            }
            return categoryList;
        }
         
        
    }
}