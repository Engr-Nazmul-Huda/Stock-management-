﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace stockmanagement.Models
{
    [Serializable]
    public class DemoCategory
    {
        public int  SL { get; set; }
        public string Name { get; set; }
    }
}