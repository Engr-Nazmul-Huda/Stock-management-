﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace stockmanagement.Models
{
    [Serializable]
    public class DemoStockOutItem
    {
        public int SL { get; set; }

        public string ItemName { get; set; }
        public string Company { get; set; }
        public int Quantity { get; set; }
    }
}