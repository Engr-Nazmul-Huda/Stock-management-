﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace stockmanagement.Models
{
    [Serializable]
    public class Company
    {
        public int CompanyID { get; set; }
        public string CompanyName { get; set; }
    }
}