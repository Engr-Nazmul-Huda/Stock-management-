﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace stockmanagement.Models
{
    [Serializable]
    public class Item
    {
        public int ItemID { get; set; }
        public string ItemName { get; set; }
        public int CategoryID { get; set; }
        public int companyID { get; set; }
        public int recordLevel { get; set; }

        public int quantity { get; set; }

    }
}