﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Manager;
using stockmanagement.Models;


namespace stockmanagement.Models
{
    [Serializable]
    public class StockIn
    {
        public int stockInID { get; set; }
        public int itemID { get; set; }

        public int stockInQuantity { get; set; }

        public DateTime stockInDate { get; set; }

    }
}