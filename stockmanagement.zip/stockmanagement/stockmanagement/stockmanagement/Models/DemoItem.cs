﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace stockmanagement.Models
{
    [Serializable]
    public class DemoItem
    {
        public int SL { get; set; }
        public string Item { get; set; }
        public string Company { get; set; }

        public string Category { get; set; }
        public int Available_Quantity { get; set; }
        public int Reorder_Level { get; set; }


    }
}