﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Models;
using stockmanagement.Manager;
namespace stockmanagement.Manager
{
    public class SeachManager
    {
        SearchGateWay aGateWay = new SearchGateWay();
        public List<Company> GetAllCompany()
        {

            return aGateWay.GetAllCompany();
        }
        public List<Category> GetAllCategory()
        {

            return aGateWay.GetAllCategory();
        }
        public List<DemoItem> GetCategoryAndCompany(Search aSearch)
        {

            return aGateWay.GetCategoryAndCompany(aSearch);
        }
        public List<DemoItem> GetCompany(Search aSearch)
        {

            return aGateWay.GetCompany(aSearch);
        }
        public List<DemoItem> GetCategory(Search aSearch)
        {

            return aGateWay.GetCategory(aSearch);
        }
    }
}