﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Manager;
using stockmanagement.Models;


namespace stockmanagement.Manager
{
    public class StockOutManager
    {
        StockOutGateWay stockOutGateWay = new StockOutGateWay();
        public string GetStockOut(StockOut stock)
        {
            int rowCount = stockOutGateWay.GetStockOut(stock);
            if (rowCount > 0)
            {
                return "Stock Out Successfully !";
            }
            return "Something Went Wrong !";
        }
        public void UpdateItem(Item item)
        {
            stockOutGateWay.UpdateItem(item);
        }
        public List<Company> GetAllCompanys()
        {

            return stockOutGateWay.GetAllCompanys();
        }
        public List<Item> GetAllItems(Item item)
        {

            return stockOutGateWay.GetAllItems(item);
        }
        public List<Item> GetOneItem(Item aitem)
        {
            return stockOutGateWay.GetOneItem(aitem);
        }
        public DemoStockOutItem GetGridItem(Item items,int i)
        {
            return stockOutGateWay.GetGridItem(items,i);
        }
    }
}
