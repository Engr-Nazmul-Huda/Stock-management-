﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Models;
namespace stockmanagement.Manager
{
    public class ItemManager
    {
        ItemGateWay aitemGateWay = new ItemGateWay();
        public string SaveNewItem(Item item)
        {
            if(aitemGateWay.IsExistItem(item))
            {
                return "This Item is already Exist ! Please try with another one.";
            }
            int rowCount = aitemGateWay.SaveNewItem(item);
            if (rowCount > 0)
            {
                return "New Item has been saved Successfully !";
            }
            return "Something Went Wrong !";
        }
        public List<Category> GetAllCategory()
        {
            return aitemGateWay.GetAllCategory();
        }
        public List<Company> GetAllCompany()
        {
            return aitemGateWay.GetAllCompany();
        }
    }
}