﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using stockmanagement.Gateway;
using stockmanagement.Manager;
using stockmanagement.Models;

namespace stockmanagement.Manager
{
   
    public class StockInmanager
    {
        StockInGateWay aGateWay = new StockInGateWay();

        public string GetStockIn(StockIn stock)
        {
            int rowCount = aGateWay.GetStockIn(stock);
            if (rowCount > 0)
            {
                return "Stock In Successfully !";
            }
            return "Something Went Wrong !";
        }
        public void UpdateItem(Item item)
        {
            aGateWay.UpdateItem(item);
        }
        public List<Company> GetAllCompanys()
        {

            return aGateWay.GetAllCompanys();
        }
        public List<Item> GetAllItems(Item item)
        {

            return aGateWay.GetAllItems(item);
        }
        public List<Item> GetOneItem(Item aitem)
        {
            return aGateWay.GetOneItem(aitem);
        }
       
    }
}