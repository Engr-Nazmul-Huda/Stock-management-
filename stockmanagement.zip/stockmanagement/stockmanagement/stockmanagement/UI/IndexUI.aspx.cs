﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using stockmanagement.Gateway;
using stockmanagement.Models;
using stockmanagement.Manager;

namespace stockmanagement
{
    public partial class IndexUI : System.Web.UI.Page
    {
        Search search = new Search();
        SeachManager aManager = new SeachManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCompanyInfo();
                GetAllCategoryInfo();
                companyViewSalesDropDownList.Items.Insert(0, new ListItem("Select Company", "0"));
                categoryViewSaleDropDownList.Items.Insert(0, new ListItem("Select Category", "0"));
            }
        }

        protected void searchButton_Click(object sender, EventArgs e)
        {
            search.CompanyID = Convert.ToInt32(companyViewSalesDropDownList.SelectedItem.Value);
            search.CategoryID = Convert.ToInt32(categoryViewSaleDropDownList.SelectedItem.Value);
            if (search.CompanyID == 0 && search.CategoryID == 0)
            {
                resultLabel.Text = "Please Select a Category or COmpany or Both and see the magic !!!";
            }
                if (search.CompanyID > 0 && search.CategoryID > 0)
            {
                searchItemGridView.DataSource = GetCategoryAndCompany(search);
                searchItemGridView.DataBind();
                if(GetCategoryAndCompany(search).Count == 0)
                {
                    resultLabel.Text = "No Data exist!!!";
                }
                else
                {
                    resultLabel.Text = "";
                }
            }
            else if (search.CompanyID > 0)
            {
                searchItemGridView.DataSource = GetCompany(search);
                searchItemGridView.DataBind();
                if (GetCompany(search).Count == 0)
                {
                    resultLabel.Text = "No Data exist!!!";
                }
                else
                {
                    resultLabel.Text = "";
                }
            }
            else if (search.CategoryID > 0)
            {
                searchItemGridView.DataSource = GetCategory(search);
                searchItemGridView.DataBind();
                if (GetCategory(search).Count == 0)
                {
                    resultLabel.Text = "No Data exist!!!";
                }
                else
                {
                    resultLabel.Text = "";
                }
               
            }
            GetAllCompanyInfo();
            GetAllCategoryInfo();
        }
        public List<DemoItem> GetCategoryAndCompany(Search aSearch)
        {

            return aManager.GetCategoryAndCompany(aSearch);
        }
        public List<DemoItem> GetCompany(Search aSearch)
        {

            return aManager.GetCompany(aSearch);
        }
        public List<DemoItem> GetCategory(Search aSearch)
        {

            return aManager.GetCategory(aSearch);
        }

        public void GetAllCompanyInfo()
        {
            companyViewSalesDropDownList.DataSource = GetAllCompany();
            companyViewSalesDropDownList.DataTextField = "companyName";
            companyViewSalesDropDownList.DataValueField = "companyID";
            companyViewSalesDropDownList.DataBind();
            companyViewSalesDropDownList.Items.Insert(0, new ListItem("Select Company", "0"));
        }
        public void GetAllCategoryInfo()
        {
         
            categoryViewSaleDropDownList.DataSource = GetAllCategory();
            categoryViewSaleDropDownList.DataTextField = "categoryName";
            categoryViewSaleDropDownList.DataValueField = "categoryID";
            categoryViewSaleDropDownList.DataBind();
            categoryViewSaleDropDownList.Items.Insert(0, new ListItem("Select Category", "0"));
        }
        public List<Company> GetAllCompany()
        {

            return aManager.GetAllCompany();
        }
        public List<Category> GetAllCategory()
        {

            return aManager.GetAllCategory();
        }

       
    }
}