﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using stockmanagement.Gateway;
using stockmanagement.Manager;
using stockmanagement.Models;

namespace stockmanagement
{
    public partial class StockOutUI : System.Web.UI.Page
    {
        Item item = new Item();
        StockOut stockOut = new StockOut();
        StockOutManager stockOutManager = new StockOutManager();
        List<DemoStockOutItem> gridViewItem;
        List<StockOut> newStockOut;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetAllCompanyInfo();
                itemStockOutDropDownList.Enabled = false;
                itemStockOutDropDownList.Items.Insert(0, new ListItem("Select Item", "0"));
            }

        }
        protected void sellButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (stockOutQuantityTextBox.Text != "")
                {
                    stockOut.ItemID = int.Parse(itemStockOutDropDownList.SelectedItem.Value);
                    stockOut.StockOutQuantity = Convert.ToInt32(stockOutQuantityTextBox.Text);
                    stockOut.StockOutDate = DateTime.Now.Date;

                    item.ItemID = stockOut.ItemID;
                    
                    List<StockOut> newStockOuts = (List<StockOut>) ViewState["newName"];
                    foreach (StockOut st in newStockOut)
                    {
                        stockOut.ItemID = st.ItemID;
                        item.ItemID = stockOut.ItemID;
                        stockOut.StockOutQuantity = st.StockOutQuantity;
                        stockOut.StockOutDate = st.StockOutDate;
                        stockOut.StockOutStateID = 1;
                        List<Item> newItems = SelectedItems(item);
                        foreach (Item i in newItems)
                        {
                            item.ItemID = i.ItemID;
                            item.quantity = i.quantity;
                        }
                        item.quantity = item.quantity - stockOut.StockOutQuantity;
                        if (item.quantity > 0)
                        {
                            string msg = stockOutManager.GetStockOut(stockOut);
                            resultLabel.Text = msg;
                        }
                       
                    }
                    stockOutQuantityTextBox.Text = "";
                   
                    //aManager.UpdateItem(item);
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void damageButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (stockOutQuantityTextBox.Text != "")
                {
                    stockOut.ItemID = int.Parse(itemStockOutDropDownList.SelectedItem.Value);
                    stockOut.StockOutQuantity = Convert.ToInt32(stockOutQuantityTextBox.Text);
                    stockOut.StockOutDate = DateTime.Now.Date;

                    item.ItemID = stockOut.ItemID;

                    List<StockOut> newStockOuts = (List<StockOut>)ViewState["newName"];
                    foreach (StockOut st in newStockOut)
                    {
                        stockOut.ItemID = st.ItemID;
                        item.ItemID = stockOut.ItemID;
                        stockOut.StockOutQuantity = st.StockOutQuantity;
                        stockOut.StockOutDate = st.StockOutDate;
                        stockOut.StockOutStateID = 2;
                        List<Item> newItems = SelectedItems(item);
                        foreach (Item i in newItems)
                        {
                            item.ItemID = i.ItemID;
                            item.quantity = i.quantity;
                        }
                        item.quantity = item.quantity - stockOut.StockOutQuantity;
                        if (item.quantity > 0)
                        {
                            string msg = stockOutManager.GetStockOut(stockOut);
                            resultLabel.Text = msg;
                        }

                    }
                    stockOutQuantityTextBox.Text = "";

                    //aManager.UpdateItem(item);
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void lostButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (stockOutQuantityTextBox.Text != "")
                {
                    stockOut.ItemID = int.Parse(itemStockOutDropDownList.SelectedItem.Value);
                    stockOut.StockOutQuantity = Convert.ToInt32(stockOutQuantityTextBox.Text);
                    stockOut.StockOutDate = DateTime.Now.Date;

                    item.ItemID = stockOut.ItemID;

                    List<StockOut> newStockOuts = (List<StockOut>)ViewState["newName"];
                    foreach (StockOut st in newStockOut)
                    {
                        stockOut.ItemID = st.ItemID;
                        item.ItemID = stockOut.ItemID;
                        stockOut.StockOutQuantity = st.StockOutQuantity;
                        stockOut.StockOutDate = st.StockOutDate;
                        stockOut.StockOutStateID = 3;
                        List<Item> newItems = SelectedItems(item);
                        foreach (Item i in newItems)
                        {
                            item.ItemID = i.ItemID;
                            item.quantity = i.quantity;
                        }
                        item.quantity = item.quantity - stockOut.StockOutQuantity;
                        if (item.quantity > 0)
                        {
                            string msg = stockOutManager.GetStockOut(stockOut);
                            resultLabel.Text = msg;
                        }

                    }
                    stockOutQuantityTextBox.Text = "";

                    //aManager.UpdateItem(item);
                }
            }
            catch (Exception ex)
            {

            }
        }
        protected void stockOutItemAddButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (stockOutQuantityTextBox.Text != "")
                {
                    stockOut.ItemID = int.Parse(itemStockOutDropDownList.SelectedItem.Value);
                    stockOut.StockOutQuantity = Convert.ToInt32(stockOutQuantityTextBox.Text);
                    item.ItemID = stockOut.ItemID;
                    item.companyID = Convert.ToInt32(companyStockOutDropDownList.SelectedItem.Value);
                    if (ViewState["name"] == null || ViewState["newName"] == null)
                    {
                       gridViewItem = new List<DemoStockOutItem>();
                        newStockOut = new List<StockOut>();
                    }
                    else
                    {
                        gridViewItem = (List<DemoStockOutItem>)ViewState["name"];
                        newStockOut = (List<StockOut>)ViewState["newName"];
                    }

                    int i = gridViewItem.Count;
                    DemoStockOutItem demoStockOutItem;
                    demoStockOutItem = GetGridItem(item,i);
                    gridViewItem.Add(demoStockOutItem);
                    newStockOut.Add(stockOut);
                    ViewState["name"] = gridViewItem;
                    ViewState["newName"] = newStockOut;
                    stockOutGridView.DataSource = gridViewItem;
                    stockOutGridView.DataBind();
                   
                     resultLabel.Text = "Add successfully In list";
                    stockOutQuantityTextBox.Text = "";
                  
                }
            }
            catch (Exception ex)
            {

            }

        }

        public DemoStockOutItem GetGridItem(Item items,int i)
        {
            return stockOutManager.GetGridItem(items,i);
        }
        protected void companyStockOutDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            itemStockOutDropDownList.Enabled = false;
            itemStockOutDropDownList.Items.Clear();
            itemStockOutDropDownList.Items.Insert(0, new ListItem("Select Item", "0"));
            item.companyID = int.Parse(companyStockOutDropDownList.SelectedItem.Value);
            if (item.companyID > 0)
            {
                GetAllItemInfo(item);
                itemStockOutDropDownList.Enabled = true;
            }
        }
        protected void itemStockOutDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Item item = new Item();
            item.ItemID = int.Parse(itemStockOutDropDownList.SelectedItem.Value);
            if (item.ItemID > 0)
            {
                List<Item> newItem = new List<Item>();
                newItem = SelectedItems(item);
                GetLoop(newItem);

            }
        }
        public void GetLoop(List<Item> newItem)
        {
            foreach (Item i in newItem)
            {
                recorderLevelstockOutTextBox.Text = i.recordLevel.ToString();
                availableStockOutQuantityTextBox.Text = i.quantity.ToString();
            }
        }
       
        public void GetAllCompanyInfo()
        {
            companyStockOutDropDownList.DataSource = GetAllCompanys();
            companyStockOutDropDownList.DataTextField = "companyName";
            companyStockOutDropDownList.DataValueField = "companyID";
            companyStockOutDropDownList.DataBind();
            companyStockOutDropDownList.Items.Insert(0, new ListItem("Select Company", "0"));
        }
        public void GetAllItemInfo(Item items)
        {
            itemStockOutDropDownList.DataSource = GetAllItems(items);
            itemStockOutDropDownList.DataTextField = "itemName";
            itemStockOutDropDownList.DataValueField = "itemID";
            itemStockOutDropDownList.DataBind();
            itemStockOutDropDownList.Items.Insert(0, new ListItem("Select Item", "0"));
        }
        public List<Company> GetAllCompanys()
        {

            return stockOutManager.GetAllCompanys();
        }
        public List<Item> GetAllItems(Item items)
        {

            return stockOutManager.GetAllItems(items);
        }
        public List<Item> SelectedItems(Item items)
        {

            return stockOutManager.GetOneItem(items);
        }

       
    }
}