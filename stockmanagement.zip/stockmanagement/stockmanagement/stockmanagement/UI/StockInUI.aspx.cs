﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using stockmanagement.Gateway;
using stockmanagement.Manager;
using stockmanagement.Models;

namespace stockmanagement
{
    public partial class StockInUI : System.Web.UI.Page
       
    {
        Item item = new Item();
        StockIn stock = new StockIn();
        StockInmanager aManager = new StockInmanager();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                GetAllCompanyInfo();
                itemStockInDropDownList.Enabled = false;
                itemStockInDropDownList.Items.Insert(0, new ListItem("Select Item", "0"));
            }
        }
       
        protected void stockitemsaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                if(stockInQuantityTextBox.Text !="")
                {
                    stock.itemID = int.Parse(itemStockInDropDownList.SelectedItem.Value);
                    stock.stockInQuantity = Convert.ToInt32(stockInQuantityTextBox.Text);
                    stock.stockInDate = DateTime.Now.Date;
                    
                    item.ItemID = stock.itemID;
                    List<Item> newItems = SelectedItems(item);
                    foreach (Item i in newItems)
                    {
                        item.ItemID = i.ItemID;
                        item.quantity = i.quantity;
                    }

                   string msg =  aManager.GetStockIn(stock);
                    resultLabel.Text = msg;
                    stockInQuantityTextBox.Text = "";
                    item.quantity = item.quantity + stock.stockInQuantity;
                    aManager.UpdateItem(item);
                   List<Item>newItem = SelectedItems(item);
                    GetLoop(newItem);
                }
            }catch(Exception ex)
            {

            }
        }
        
        public void GetAllCompanyInfo()
        {
            companyStockInDropDownList.DataSource = GetAllCompanys();
            companyStockInDropDownList.DataTextField = "companyName";
            companyStockInDropDownList.DataValueField = "companyID";
            companyStockInDropDownList.DataBind();
            companyStockInDropDownList.Items.Insert(0, new ListItem("Select Company", "0"));
        }
        public void GetAllItemInfo(Item items)
        {
            itemStockInDropDownList.DataSource = GetAllItems(items);
            itemStockInDropDownList.DataTextField = "itemName";
            itemStockInDropDownList.DataValueField = "itemID";
            itemStockInDropDownList.DataBind();
            itemStockInDropDownList.Items.Insert(0, new ListItem("Select Item", "0"));
        }
        public List<Company> GetAllCompanys()
        {

            return aManager.GetAllCompanys();
        }
        public List<Item> GetAllItems(Item items)
        {

            return aManager.GetAllItems(items);
        }
        public List<Item> SelectedItems(Item items)
        {

            return aManager.GetOneItem(items);
        }

        protected void companyStockInDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            itemStockInDropDownList.Enabled = false;
            itemStockInDropDownList.Items.Clear();
            itemStockInDropDownList.Items.Insert(0, new ListItem("Select Item", "0"));
            item.companyID = int.Parse(companyStockInDropDownList.SelectedItem.Value);
            if(item.companyID > 0)
            {
                GetAllItemInfo(item);
                itemStockInDropDownList.Enabled = true;
            }
        }

        protected void itemStockInDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            Item item = new Item();
            item.ItemID = int.Parse(itemStockInDropDownList.SelectedItem.Value);
            if(item.ItemID > 0)
            {
                List<Item> newItem = new List<Item>();
                newItem = SelectedItems(item);
                //  recorderLevelstockInTextBox.Text = newItem.
                GetLoop(newItem);
               
            }
        }
        public void GetLoop(List<Item> newItem)
        {
            foreach (Item i in newItem)
            {
                recorderLevelstockInTextBox.Text = i.recordLevel.ToString();
                availableInQuantityTextBox.Text = i.quantity.ToString();
            }
        }

    }
}