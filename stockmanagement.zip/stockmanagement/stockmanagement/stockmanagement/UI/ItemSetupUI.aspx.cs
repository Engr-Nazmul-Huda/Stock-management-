﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using stockmanagement.Manager;
using stockmanagement.Models;
using stockmanagement.Gateway;

namespace stockmanagement
{
    public partial class ItemSetupUI : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                GetCategoryInfo();
                GetCompanyInfo();
            }
        }
        ItemManager aitemManager = new ItemManager();
        protected void itemsaveButton_Click(object sender, EventArgs e)
        {
            if(itemTextBox.Text != "")
            {
                Item item = new Item();
                item.ItemName = itemTextBox.Text;
                item.companyID = Convert.ToInt32(companyDropDownList.SelectedItem.Value);
                item.CategoryID = Convert.ToInt32(categoryDropDownList.SelectedItem.Value);
                item.recordLevel = Convert.ToInt32(reorderTextBox.Text);
                item.quantity = 0;
                string messege = aitemManager.SaveNewItem(item);
                resultLabel.Text = messege;
                itemTextBox.Text = "";
                reorderTextBox.Text = "0";
                GetCategoryInfo();
                GetCompanyInfo();
            }
            else
            {
                resultLabel.Text = "please insert an item name.";
            }
           

        }
        public void GetCategoryInfo()
        {
            categoryDropDownList.DataSource = GetAllCategory();
            categoryDropDownList.DataTextField = "categoryName";
            categoryDropDownList.DataValueField = "categoryID";
            categoryDropDownList.DataBind();
        }
        public void GetCompanyInfo()
        {
            companyDropDownList.DataSource = GetAllCompany();
            companyDropDownList.DataTextField = "companyName";
            companyDropDownList.DataValueField = "companyID";
            companyDropDownList.DataBind();
        }
        public List<Category> GetAllCategory()
        {
            return aitemManager.GetAllCategory();
        }
        public List<Company> GetAllCompany()
        {
            return aitemManager.GetAllCompany();
        }
    }
}